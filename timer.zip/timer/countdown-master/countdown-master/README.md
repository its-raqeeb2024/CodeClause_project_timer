<div align="center">
  <img src="assets/project_logo.png" />
  <h2>Countdown</h2>
  <p>A custom countdown web-application</p>
</div>

<div align="center">

  <!-- HTML -->
  <img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white">

  <!-- CSS -->
  <img src="https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white">

  <!-- JAVASCRIPT -->
  <img src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E">

  <!-- MORE BADGES visit https://github.com/Ileriayo/markdown-badges -->

</div>

<div align="center">
  <!-- REPO VIEWS -->
  <img src="https://visitor-badge.glitch.me/badge?page_id=juzershakir.countdown&left_color=black&right_color=green&style=for-the-badge&logo=Github"/>
  <!-- WAKATIME -->
    <a href="https://wakatime.com/badge/user/ccef187f-4308-4666-920d-d0a9a07d713a/project/cc01c9e5-5e2c-45e6-a668-67acafb76f18"><img src="https://wakatime.com/badge/user/ccef187f-4308-4666-920d-d0a9a07d713a/project/cc01c9e5-5e2c-45e6-a668-67acafb76f18.svg" alt="wakatime"></a>
</div>

<br>

<div align="center">
  <!-- BUY ME COFFEE -->
  <a href="https://www.buymeacoffee.com/juzershakir"> <img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" height="50" width="210" alt="juzershakir" /></a>
</div>
